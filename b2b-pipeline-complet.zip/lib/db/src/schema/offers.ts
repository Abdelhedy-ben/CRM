import { createInsertSchema } from "drizzle-zod";
import {
  date,
  integer,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const offersTable = pgTable("pipeline_offers", {
  id: serial("id").primaryKey(),
  client: text("client").notNull(),
  ref: text("ref").notNull(),
  contact: text("contact"),
  email: text("email"),
  details: text("details"),
  formation: text("formation").notNull(),
  hackerspace: text("hackerspace"),
  participantCount: integer("participant_count").notNull().default(1),
  pauseMinutesPerDay: numeric("pause_minutes_per_day", {
    precision: 8,
    scale: 2,
    mode: "number",
  }).notNull().default(0),
  trainerRatePerHour: numeric("trainer_rate_per_hour", {
    precision: 12,
    scale: 2,
    mode: "number",
  }).notNull().default(0),
  transportFees: numeric("transport_fees", {
    precision: 12,
    scale: 2,
    mode: "number",
  }).notNull().default(0),
  hoursPerDay: numeric("hours_per_day", {
    precision: 6,
    scale: 2,
    mode: "number",
  }).notNull().default(6),
  days: numeric("days", {
    precision: 6,
    scale: 2,
    mode: "number",
  }).notNull().default(1),
  instructor: text("instructor"),
  priority: text("priority").notNull().default("Moyenne"),
  offerStatus: text("offer_status").notNull().default("Prospect"),
  paymentStatus: text("payment_status").notNull().default("Non Payé"),
  amountExclTax: numeric("amount_excl_tax", {
    precision: 12,
    scale: 2,
    mode: "number",
  }).notNull().default(0),
  amountCollected: numeric("amount_collected", {
    precision: 12,
    scale: 2,
    mode: "number",
  }).notNull().default(0),
  submittedAt: date("submitted_at", { mode: "string" }),
  startDate: date("start_date", { mode: "string" }),
  archivedAt: timestamp("archived_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertOfferSchema = createInsertSchema(offersTable).omit({
  id: true,
  archivedAt: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertOffer = z.infer<typeof insertOfferSchema>;
export type Offer = typeof offersTable.$inferSelect;