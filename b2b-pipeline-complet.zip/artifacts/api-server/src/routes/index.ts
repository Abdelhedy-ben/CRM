import { Router, type IRouter } from "express";
import healthRouter from "./health";
import instructorsRouter from "./instructors";
import offersRouter from "./offers";

const router: IRouter = Router();

router.use(healthRouter);
router.use(offersRouter);
router.use(instructorsRouter);

export default router;
