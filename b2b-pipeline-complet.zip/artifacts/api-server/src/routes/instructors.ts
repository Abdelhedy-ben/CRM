import { asc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateInstructorBody,
  CreateInstructorResponse,
  DeleteInstructorParams,
  DeleteInstructorResponse,
  GetInstructorsResponse,
  UpdateInstructorBody,
  UpdateInstructorParams,
  UpdateInstructorResponse,
} from "@workspace/api-zod";
import { db, instructorsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/instructors", async (_req, res): Promise<void> => {
  const instructors = await db
    .select()
    .from(instructorsTable)
    .orderBy(asc(instructorsTable.name));

  res.json(GetInstructorsResponse.parse(instructors));
});

router.post("/instructors", async (req, res): Promise<void> => {
  const parsed = CreateInstructorBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [instructor] = await db
    .insert(instructorsTable)
    .values({
      name: parsed.data.name,
      email: parsed.data.email ?? null,
      phone: parsed.data.phone ?? null,
      track: parsed.data.track ?? null,
    })
    .returning();

  res.status(201).json(CreateInstructorResponse.parse(instructor));
});

router.put("/instructors/:id", async (req, res): Promise<void> => {
  const params = UpdateInstructorParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateInstructorBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [instructor] = await db
    .update(instructorsTable)
    .set({
      name: parsed.data.name,
      email: parsed.data.email ?? null,
      phone: parsed.data.phone ?? null,
      track: parsed.data.track ?? null,
      updatedAt: new Date(),
    })
    .where(eq(instructorsTable.id, params.data.id))
    .returning();

  if (!instructor) {
    res.status(404).json({ error: "Formateur introuvable" });
    return;
  }

  res.json(UpdateInstructorResponse.parse(instructor));
});

router.delete("/instructors/:id", async (req, res): Promise<void> => {
  const params = DeleteInstructorParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [instructor] = await db
    .delete(instructorsTable)
    .where(eq(instructorsTable.id, params.data.id))
    .returning({ id: instructorsTable.id });

  if (!instructor) {
    res.status(404).json({ error: "Formateur introuvable" });
    return;
  }

  res.json(DeleteInstructorResponse.parse({ id: instructor.id, deleted: true }));
});

export default router;