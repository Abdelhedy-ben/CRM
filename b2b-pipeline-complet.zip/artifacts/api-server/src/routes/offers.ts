import { and, desc, eq, isNull, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  ArchiveOfferParams,
  ArchiveOfferResponse,
  CreateOfferBody,
  CreateOfferResponse,
  GetOfferSummaryResponse,
  GetOffersResponse,
  UpdateOfferBody,
  UpdateOfferParams,
  UpdateOfferResponse,
} from "@workspace/api-zod";
import { db, offersTable } from "@workspace/db";

const router: IRouter = Router();

function asDateOnly(value: Date | null | undefined): string | null {
  return value ? value.toISOString().slice(0, 10) : null;
}

router.get("/offers", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(offersTable)
    .where(isNull(offersTable.archivedAt))
    .orderBy(desc(offersTable.submittedAt), desc(offersTable.id));

  res.json(GetOffersResponse.parse(rows));
});

router.get("/offers/summary", async (_req, res): Promise<void> => {
  const directCharges = sql`
    greatest(${offersTable.hoursPerDay} - ${offersTable.pauseMinutesPerDay} / 60.0, 0)
      * ${offersTable.days} * ${offersTable.trainerRatePerHour}
      + ${offersTable.transportFees}
  `;
  const [summary] = await db
    .select({
      totalOffers: sql<number>`count(*)::int`,
      closedOffers: sql<number>`count(*) filter (where ${offersTable.offerStatus} = 'Payé / Clôturé')::int`,
      totalQuoted: sql<number>`coalesce(sum(${offersTable.amountExclTax}), 0)::float8`,
      totalCollected: sql<number>`coalesce(sum(${offersTable.amountCollected}), 0)::float8`,
      totalOutstanding: sql<number>`coalesce(sum(greatest(${offersTable.amountExclTax} - ${offersTable.amountCollected}, 0)), 0)::float8`,
      totalCharges: sql<number>`coalesce(sum(${directCharges}), 0)::float8`,
      totalGain: sql<number>`coalesce(sum(${offersTable.amountExclTax} - (${directCharges})), 0)::float8`,
    })
    .from(offersTable)
    .where(isNull(offersTable.archivedAt));

  res.json(GetOfferSummaryResponse.parse(summary));
});

router.post("/offers", async (req, res): Promise<void> => {
  const parsed = CreateOfferBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;
  const [offer] = await db
    .insert(offersTable)
    .values({
      client: data.client,
      ref: data.ref,
      contact: data.contact ?? null,
      email: data.email ?? null,
      details: data.details ?? null,
      formation: data.formation,
      hackerspace: data.hackerspace ?? null,
      participantCount: data.participantCount,
      pauseMinutesPerDay: data.pauseMinutesPerDay,
      trainerRatePerHour: data.trainerRatePerHour,
      transportFees: data.transportFees,
      hoursPerDay: data.hoursPerDay,
      days: data.days,
      instructor: data.instructor ?? null,
      priority: data.priority ?? "Moyenne",
      offerStatus: data.offerStatus ?? "Prospect",
      paymentStatus: data.paymentStatus ?? "Non Payé",
      amountExclTax: data.amountExclTax,
      amountCollected: data.amountCollected,
      submittedAt: asDateOnly(data.submittedAt),
      startDate: asDateOnly(data.startDate),
    })
    .returning();

  res.status(201).json(CreateOfferResponse.parse(offer));
});

router.put("/offers/:id", async (req, res): Promise<void> => {
  const params = UpdateOfferParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateOfferBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;
  const [offer] = await db
    .update(offersTable)
    .set({
      client: data.client,
      ref: data.ref,
      contact: data.contact ?? null,
      email: data.email ?? null,
      details: data.details ?? null,
      formation: data.formation,
      hackerspace: data.hackerspace ?? null,
      participantCount: data.participantCount,
      pauseMinutesPerDay: data.pauseMinutesPerDay,
      trainerRatePerHour: data.trainerRatePerHour,
      transportFees: data.transportFees,
      hoursPerDay: data.hoursPerDay,
      days: data.days,
      instructor: data.instructor ?? null,
      priority: data.priority ?? "Moyenne",
      offerStatus: data.offerStatus ?? "Prospect",
      paymentStatus: data.paymentStatus ?? "Non Payé",
      amountExclTax: data.amountExclTax,
      amountCollected: data.amountCollected,
      submittedAt: asDateOnly(data.submittedAt),
      startDate: asDateOnly(data.startDate),
      updatedAt: new Date(),
    })
    .where(
      and(eq(offersTable.id, params.data.id), isNull(offersTable.archivedAt)),
    )
    .returning();

  if (!offer) {
    res.status(404).json({ error: "Offre introuvable" });
    return;
  }
  res.json(UpdateOfferResponse.parse(offer));
});

router.delete("/offers/:id", async (req, res): Promise<void> => {
  const params = ArchiveOfferParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [offer] = await db
    .update(offersTable)
    .set({ archivedAt: new Date(), updatedAt: new Date() })
    .where(
      and(eq(offersTable.id, params.data.id), isNull(offersTable.archivedAt)),
    )
    .returning({ id: offersTable.id });

  if (!offer) {
    res.status(404).json({ error: "Offre introuvable" });
    return;
  }

  res.json(ArchiveOfferResponse.parse({ id: offer.id, archived: true }));
});

export default router;