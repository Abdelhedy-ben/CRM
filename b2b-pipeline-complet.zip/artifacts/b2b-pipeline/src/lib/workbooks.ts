import type { Instructor, Offer } from '@workspace/api-client-react';

export type WorkbookRow = { rowNumber: number; values: Record<string, unknown> };

const offerColumns: Array<[string, keyof Offer]> = [
  ['ID offre', 'id'],
  ['Référence', 'ref'], ['Client', 'client'], ['Contact', 'contact'], ['E-mail', 'email'],
  ['Détails', 'details'], ['Formation', 'formation'], ['Lieu / hackerspace', 'hackerspace'],
  ['Participants', 'participantCount'], ['Pause (min / jour)', 'pauseMinutesPerDay'],
  ['Tarif formateur / heure', 'trainerRatePerHour'], ['Frais de transport', 'transportFees'],
  ['Heures / jour', 'hoursPerDay'], ['Nombre de jours', 'days'], ['Formateur', 'instructor'],
  ['Priorité', 'priority'], ['Étape de l’offre', 'offerStatus'], ['Statut de paiement', 'paymentStatus'],
  ['Montant HT (TND)', 'amountExclTax'], ['Montant encaissé (TND)', 'amountCollected'],
  ['Date d’envoi', 'submittedAt'], ['Date de début', 'startDate'],
  ['Créée le', 'createdAt'], ['Modifiée le', 'updatedAt'],
];
const instructorColumns: Array<[string, keyof Instructor]> = [
  ['ID formateur', 'id'], ['Nom complet', 'name'], ['E-mail', 'email'], ['Téléphone', 'phone'],
  ['Spécialité / parcours', 'track'], ['Créé le', 'createdAt'],
];

export async function readWorkbookRows(file: File): Promise<WorkbookRow[]> {
  const XLSX = await import('xlsx');
  const bytes = await file.arrayBuffer();
  const workbook = XLSX.read(bytes, { type: 'array', cellDates: true });
  const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
  if (!firstSheet) throw new Error('Le classeur ne contient aucune feuille.');
  const matrix = XLSX.utils.sheet_to_json<unknown[]>(firstSheet, { header: 1, defval: null, raw: true });
  if (matrix.length < 2) return [];
  const headers = matrix[0].map(value => String(value ?? '').trim());
  if (headers.every(header => !header)) throw new Error('La première ligne doit contenir les noms des colonnes.');
  return matrix.slice(1).flatMap((cells, index) => {
    const values: Record<string, unknown> = {};
    headers.forEach((header, column) => {
      if (header) values[header] = cells[column] ?? null;
    });
    return Object.values(values).some(value => value !== null && value !== '') ? [{ rowNumber: index + 2, values }] : [];
  });
}

function makeSheet<T extends object>(XLSX: typeof import('xlsx'), records: T[], columns: Array<[string, keyof T]>) {
  const sheet = XLSX.utils.aoa_to_sheet([
    columns.map(([label]) => label),
    ...records.map(record => columns.map(([, key]) => {
      const value = record[key];
      if ((key === 'submittedAt' || key === 'startDate' || key === 'createdAt' || key === 'updatedAt') && value) {
        return new Date(String(value)).toLocaleDateString('fr-CA');
      }
      return value ?? '';
    })),
  ]);
  sheet['!cols'] = columns.map(([label]) => ({ wch: Math.max(label.length + 3, 18) }));
  return sheet;
}

function downloadWorkbook<T extends object>(XLSX: typeof import('xlsx'), records: T[], columns: Array<[string, keyof T]>, sheetName: string, filename: string) {
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, makeSheet(XLSX, records, columns), sheetName);
  XLSX.writeFile(workbook, filename, { bookType: 'xlsx', compression: true });
}

export async function exportOffersWorkbook(offers: Offer[]) {
  const XLSX = await import('xlsx');
  downloadWorkbook(XLSX, offers, offerColumns, 'Offres', 'offres-miftah.xlsx');
}

export async function exportInstructorsWorkbook(instructors: Instructor[]) {
  const XLSX = await import('xlsx');
  downloadWorkbook(XLSX, instructors, instructorColumns, 'Formateurs', 'formateurs-miftah.xlsx');
}

export function normalizedHeader(value: string) {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

export function workbookValue(row: Record<string, unknown>, ...aliases: string[]): unknown {
  const indexed = new Map(Object.entries(row).map(([key, value]) => [normalizedHeader(key), value]));
  for (const alias of aliases) {
    const value = indexed.get(normalizedHeader(alias));
    if (value !== undefined) return value;
  }
  return undefined;
}

export function workbookDate(value: unknown): string {
  if (value === null || value === undefined || value === '') return '';
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value.toISOString().slice(0, 10);
  if (typeof value === 'number') {
    if (value >= 1) {
      const parsed = new Date(Date.UTC(1899, 11, 30) + Math.floor(value) * 86_400_000);
      if (!Number.isNaN(parsed.getTime())) return parsed.toISOString().slice(0, 10);
    }
  }
  const text = String(value).trim();
  if (/^\d{4}-\d{1,2}-\d{1,2}/.test(text)) return text.slice(0, 10);
  const parsed = new Date(text);
  return Number.isNaN(parsed.getTime()) ? text : parsed.toISOString().slice(0, 10);
}