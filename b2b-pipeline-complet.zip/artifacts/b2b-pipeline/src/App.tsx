import { useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import {
  useArchiveOffer, useCreateOffer, useUpdateOffer, useGetOffers, useGetOfferSummary,
  useCreateInstructor, useUpdateInstructor, useGetInstructors, useDeleteInstructor,
  getGetOffersQueryKey, getGetOfferSummaryQueryKey, getGetInstructorsQueryKey,
} from '@workspace/api-client-react';
import type { Offer, OfferInput, Instructor, InstructorInput } from '@workspace/api-client-react';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import NotFound from '@/pages/not-found';
import {
  Activity, ArrowDownToLine, ArrowRight, BadgeCheck, Banknote, BookOpen, Calculator,
  CalendarDays, Check, ChevronDown, CircleAlert, Clock3, FileSpreadsheet, FileText,
  Filter, GraduationCap, LayoutDashboard, LoaderCircle, Mail, Menu, Pencil, Plus,
  Search, ShieldCheck, Trash2, TrendingUp, Users, X,
} from 'lucide-react';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ErrorBoundary } from '@/components/error-boundary';
import type { ReactNode } from 'react';
import {
  exportInstructorsWorkbook, exportOffersWorkbook, readWorkbookRows,
  workbookDate, workbookValue,
} from '@/lib/workbooks';

const client = new QueryClient({ defaultOptions: { queries: { staleTime: 20_000, retry: 1 } } });
const stages = ['Prospect', 'Devis Envoyé', 'En Préparation Logistique', 'Payé / Clôturé', 'Perdu'] as const;
const payments = ['Non Payé', 'Partiellement Payé', 'Payé / Clôturé'] as const;
const priorities = ['Basse', 'Moyenne', 'Haute'] as const;
const money = (value: number) => new Intl.NumberFormat('fr-TN', { style: 'currency', currency: 'TND', maximumFractionDigits: 0 }).format(value || 0);
const dateText = (value?: string | null) => value ? new Date(value).toLocaleDateString('fr-TN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
const dateFieldSchema = z.string().refine(value => !value || (/^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(new Date(`${value}T00:00:00Z`).getTime()) && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value), 'Date invalide');
const offerSchema = z.object({
  client: z.string().min(1, 'Le client est obligatoire'), ref: z.string().min(1, 'La référence est obligatoire'),
  contact: z.string().optional(), email: z.string().email('Adresse e-mail invalide').or(z.literal('')).optional(),
  details: z.string().optional(), formation: z.string().min(1, 'La formation est obligatoire'), hackerspace: z.string().optional(),
  participantCount: z.coerce.number().min(1), pauseMinutesPerDay: z.coerce.number().min(0),
  trainerRatePerHour: z.coerce.number().min(0), transportFees: z.coerce.number().min(0),
  hoursPerDay: z.coerce.number().min(0), days: z.coerce.number().min(0),
  instructor: z.string().optional(), priority: z.enum(priorities), offerStatus: z.enum(stages),
  paymentStatus: z.enum(payments), amountExclTax: z.coerce.number().min(0), amountCollected: z.coerce.number().min(0),
  submittedAt: dateFieldSchema.optional(), startDate: dateFieldSchema.optional(),
});
const instructorSchema = z.object({
  name: z.string().min(1, 'Le nom est obligatoire'), email: z.string().email('Adresse e-mail invalide').or(z.literal('')).optional(),
  phone: z.string().optional(), track: z.string().optional(),
});
type OfferValues = z.infer<typeof offerSchema>;
type InstructorValues = z.infer<typeof instructorSchema>;
type ImportFeedback = { kind: 'success' | 'error'; message: string; issues?: string[] };
const cellText = (value: unknown) => value === null || value === undefined ? '' : String(value).trim();
function cellNumber(value: unknown, fallback: number): number {
  if (value === null || value === undefined || value === '') return fallback;
  if (typeof value === 'number') return value;
  let normalized = String(value).replace(/\s/g, '').replace(/[^\d,.-]/g, '');
  if (normalized.includes(',') && normalized.includes('.')) normalized = normalized.replace(/\./g, '').replace(',', '.');
  else normalized = normalized.replace(',', '.');
  const number = Number(normalized);
  return Number.isFinite(number) ? number : Number.NaN;
}
function importErrorMessage(error: unknown) {
  return error instanceof Error && error.message ? error.message : 'Une erreur inattendue est survenue.';
}
function ImportNotice({ feedback }: { feedback: ImportFeedback | null }) {
  if (!feedback) return null;
  return <div role={feedback.kind === 'error' ? 'alert' : 'status'} data-testid={`import-feedback-${feedback.kind}`}
    className={`mt-3 rounded-lg border px-3 py-2.5 text-xs ${feedback.kind === 'error' ? 'border-rose-200 bg-rose-50 text-rose-800' : 'border-emerald-200 bg-emerald-50 text-emerald-800'}`}>
    <p className="m-0 font-semibold">{feedback.message}</p>
    {!!feedback.issues?.length && <ul className="mb-0 mt-1 list-disc pl-4">{feedback.issues.map((issue, index) => <li key={`${index}-${issue}`}>{issue}</li>)}</ul>}
  </div>;
}

function Shell({ children }: { children: ReactNode }) {
  const [path] = useLocation();
  const links = [
    { href: '/', label: 'Vue d’ensemble', icon: LayoutDashboard },
    { href: '/instructors', label: 'Formateurs', icon: Users },
    { href: '/simulation', label: 'Simulateur', icon: Calculator },
  ];
  return <div className="min-h-[100dvh] bg-background">
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[248px] flex-col bg-[hsl(var(--sidebar))] text-[hsl(var(--sidebar-foreground))] md:flex">
      <div className="px-6 pb-7 pt-7">
        <Link href="/" className="flex items-center gap-3 no-underline" data-testid="link-brand-home">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--accent))] text-white"><BookOpen size={19}/></div>
          <div><div className="font-display text-[17px] font-extrabold tracking-tight text-white">GOMYCODE</div><div className="mt-0.5 text-[10px] uppercase tracking-[.22em] text-white/50">CRM B2B</div></div>
        </Link>
      </div>
      <div className="mx-5 mb-3 border-t border-white/10" />
      <p className="px-6 pb-2 pt-2 text-[10px] font-bold uppercase tracking-[.2em] text-white/38">Espace de travail</p>
      <nav className="space-y-1 px-3" aria-label="Navigation principale">
        {links.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-nav-${href === '/' ? 'overview' : href.slice(1)}`}
          className={`group flex items-center gap-3 rounded-lg px-3 py-3 text-[13px] font-semibold transition-colors ${path === href ? 'bg-white/10 text-white' : 'text-white/58 hover:bg-white/5 hover:text-white'}`}>
          <Icon size={17} strokeWidth={1.8} className={path === href ? 'text-[hsl(var(--accent))]' : 'text-white/52'}/>{label}
          {path === href && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent))]"/>}
        </Link>)}
      </nav>
      <div className="mt-auto px-5 pb-5">
        <div className="rounded-xl border border-white/10 bg-white/[.045] p-4">
          <div className="mb-2 flex items-center gap-2 text-xs font-semibold text-white/80"><ShieldCheck size={14} className="text-[hsl(var(--accent))]"/>Suivi opérationnel</div>
          <p className="m-0 text-[11px] leading-relaxed text-white/45">Offres, règlements et équipe réunis au même endroit.</p>
        </div>
        <p className="mb-0 mt-4 text-center font-mono text-[10px] text-white/30">TUNIS · {new Date().getFullYear()}</p>
      </div>
    </aside>
    <div className="md:pl-[248px]">
      <header className="sticky top-0 z-20 flex h-[66px] items-center justify-between border-b border-border/80 bg-background/95 px-4 backdrop-blur md:px-8">
        <div className="flex items-center gap-3">
          <div className="grid h-8 w-8 place-items-center rounded-lg bg-[hsl(var(--sidebar))] text-white md:hidden"><BookOpen size={16}/></div>
          <div className="md:hidden font-display font-extrabold">GOMYCODE</div>
          <span className="hidden text-xs text-muted-foreground md:block">Centre de formation <span className="mx-2 text-border">/</span> <span className="font-semibold text-foreground">{path === '/instructors' ? 'Formateurs' : path === '/simulation' ? 'Simulateur' : path === '/' ? 'Pipeline' : 'Page'}</span></span>
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-[11px] font-medium text-muted-foreground sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--primary))]"/>TND · Dinar tunisien</span>
          <div className="grid h-8 w-8 place-items-center rounded-full bg-[hsl(var(--primary))] text-[10px] font-bold text-white" data-testid="text-user-avatar">GC</div>
        </div>
      </header>
      <nav className="flex gap-1 border-b border-border bg-card px-3 py-2 md:hidden">
        {links.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`mobile-nav-${href === '/' ? 'overview' : href.slice(1)}`} className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[11px] font-semibold ${path === href ? 'bg-[hsl(var(--primary))] text-white' : 'text-muted-foreground'}`}><Icon size={14}/>{label}</Link>)}
      </nav>
      <main className="mx-auto max-w-[1540px] px-4 pb-12 pt-7 md:px-8 md:pt-9">{children}</main>
    </div>
  </div>;
}

function PageTitle({ eyebrow, title, detail, action }: { eyebrow: string; title: string; detail: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
    <div><div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.2em] text-[hsl(var(--primary))]"><span className="h-px w-5 bg-[hsl(var(--accent))]"/>{eyebrow}</div>
      <h1 className="m-0 font-display text-[30px] font-extrabold leading-tight tracking-[-.04em] text-foreground md:text-[36px]" data-testid="text-page-title">{title}</h1>
      <p className="mb-0 mt-2 text-sm text-muted-foreground">{detail}</p></div>{action}
  </div>;
}

function Metric({ label, value, note, icon: Icon, tone = 'teal' }: { label: string; value: string; note: string; icon: typeof Activity; tone?: 'teal' | 'orange' | 'blue' }) {
  return <div className="relative overflow-hidden rounded-xl border border-border bg-card p-4 shadow-[0_2px_12px_rgba(32,48,54,.025)] md:p-5">
    <div className="flex items-start justify-between"><div className="text-[11px] font-bold uppercase tracking-[.1em] text-muted-foreground">{label}</div><span className={`grid h-8 w-8 place-items-center rounded-lg ${tone === 'orange' ? 'bg-[hsl(var(--accent))]/10 text-[hsl(var(--accent))]' : tone === 'blue' ? 'bg-sky-900/10 text-sky-900' : 'bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]'}`}><Icon size={16}/></span></div>
    <div className="mt-4 font-display text-[25px] font-extrabold tracking-[-.04em] text-foreground" data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</div><div className="mt-1 text-[11px] text-muted-foreground">{note}</div>
  </div>;
}

function StatePanel({ type, onRetry }: { type: 'loading' | 'error' | 'empty'; onRetry?: () => void }) {
  if (type === 'loading') return <div className="space-y-3 p-6" data-testid="state-loading">{[0, 1, 2, 3].map(i => <div key={i} className="h-14 animate-pulse rounded-lg bg-muted"/>)}</div>;
  if (type === 'error') return <div className="grid place-items-center px-5 py-14 text-center" data-testid="state-error"><CircleAlert className="mb-3 text-destructive" size={26}/><h3 className="m-0 font-display text-lg font-bold">Impossible de charger ces données</h3><p className="text-sm text-muted-foreground">Vérifiez votre connexion puis réessayez.</p><Button variant="outline" onClick={onRetry} data-testid="button-retry">Réessayer</Button></div>;
  return <div className="grid place-items-center px-5 py-16 text-center" data-testid="state-empty"><div className="mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-muted text-[hsl(var(--primary))]"><FileText size={22}/></div><h3 className="m-0 font-display text-lg font-bold">Rien à afficher pour le moment</h3><p className="max-w-sm text-sm text-muted-foreground">Ajoutez une première entrée pour commencer votre suivi.</p></div>;
}

function StatusPill({ label }: { label: string }) {
  const style = label === 'Payé / Clôturé' ? 'bg-emerald-100 text-emerald-800' : label === 'Perdu' ? 'bg-rose-100 text-rose-800' : label === 'Haute' ? 'bg-orange-100 text-orange-800' : label === 'Partiellement Payé' ? 'bg-amber-100 text-amber-800' : label === 'Prospect' ? 'bg-slate-200 text-slate-700' : 'bg-teal-100 text-teal-800';
  return <span className={`inline-flex max-w-full items-center rounded-full px-2.5 py-1 text-[10px] font-bold leading-tight ${style}`} data-testid={`status-${label.toLowerCase().replaceAll(/[^a-z]+/g, '-')}`}>{label}</span>;
}

function Field({ name, label, form, type = 'text', placeholder, required = false, multiline = false }: any) {
  return <FormField control={form.control} name={name} render={({ field }) => <FormItem className="space-y-1.5">
    <FormLabel className="text-[11px] font-semibold text-foreground">{label}{required && <span className="ml-1 text-[hsl(var(--accent))]">*</span>}</FormLabel>
    <FormControl>{multiline ? <Textarea {...field} value={field.value ?? ''} placeholder={placeholder} className="min-h-[76px] resize-y bg-background text-sm" data-testid={`input-${name}`}/> : <Input {...field} value={field.value ?? ''} type={type} placeholder={placeholder} className="h-10 bg-background text-sm" data-testid={`input-${name}`}/>}</FormControl><FormMessage className="text-[11px]"/>
  </FormItem>}/>
}
function SelectField({ name, label, form, options, placeholder }: any) {
  return <FormField control={form.control} name={name} render={({ field }) => <FormItem className="space-y-1.5">
    <FormLabel className="text-[11px] font-semibold">{label}</FormLabel><FormControl><select {...field} value={field.value ?? ''} className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" data-testid={`select-${name}`}><option value="" disabled>{placeholder || 'Sélectionner'}</option>{options.map((option: string) => <option key={option} value={option}>{option}</option>)}</select></FormControl><FormMessage className="text-[11px]"/>
  </FormItem>}/>
}
function Modal({ title, subtitle, onClose, children, wide = false }: { title: string; subtitle: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-[hsl(211_28%_12%/.55)] p-0 backdrop-blur-[2px] sm:items-center sm:p-5" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <section className={`fade-up max-h-[92dvh] w-full overflow-hidden rounded-t-2xl border border-border bg-card shadow-2xl sm:rounded-2xl ${wide ? 'max-w-3xl' : 'max-w-xl'}`} role="dialog" aria-modal="true">
      <div className="flex items-start justify-between border-b border-border px-5 py-4 sm:px-7"><div><h2 className="m-0 font-display text-xl font-extrabold tracking-tight">{title}</h2><p className="mb-0 mt-1 text-xs text-muted-foreground">{subtitle}</p></div><button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-muted" aria-label="Fermer" data-testid="button-close-modal"><X size={17}/></button></div>
      <div className="scrollbar-thin max-h-[calc(92dvh-82px)] overflow-y-auto px-5 py-5 sm:px-7">{children}</div>
    </section>
  </div>;
}

function OfferFormModal({ offer, onClose }: { offer?: Offer; onClose: () => void }) {
  const qc = useQueryClient();
  const create = useCreateOffer(); const update = useUpdateOffer();
  const instructorsQuery = useGetInstructors();
  const form = useForm<OfferValues>({ resolver: zodResolver(offerSchema), defaultValues: {
    client: offer?.client ?? '', ref: offer?.ref ?? '', contact: offer?.contact ?? '', email: offer?.email ?? '', details: offer?.details ?? '', formation: offer?.formation ?? '', hackerspace: offer?.hackerspace ?? '',
    participantCount: offer?.participantCount ?? 1, pauseMinutesPerDay: offer?.pauseMinutesPerDay ?? 0, trainerRatePerHour: offer?.trainerRatePerHour ?? 0, transportFees: offer?.transportFees ?? 0,
    hoursPerDay: offer?.hoursPerDay ?? 0, days: offer?.days ?? 1, instructor: offer?.instructor ?? '', priority: offer?.priority ?? 'Moyenne',
    offerStatus: offer?.offerStatus ?? 'Prospect', paymentStatus: offer?.paymentStatus ?? 'Non Payé', amountExclTax: offer?.amountExclTax ?? 0, amountCollected: offer?.amountCollected ?? 0,
    submittedAt: offer?.submittedAt?.slice(0, 10) ?? '', startDate: offer?.startDate?.slice(0, 10) ?? '',
  } });
  const finish = () => { qc.invalidateQueries({ queryKey: getGetOffersQueryKey() }); qc.invalidateQueries({ queryKey: getGetOfferSummaryQueryKey() }); onClose(); };
  const submit = (values: OfferValues) => {
    const payload: OfferInput = { ...values, contact: values.contact || null, email: values.email || null, details: values.details || null, hackerspace: values.hackerspace || null, instructor: values.instructor || null, submittedAt: values.submittedAt || null, startDate: values.startDate || null };
    if (offer) update.mutate({ id: offer.id, data: payload }, { onSuccess: finish });
    else create.mutate({ data: payload }, { onSuccess: finish });
  };
  const busy = create.isPending || update.isPending;
  return <Modal title={offer ? 'Modifier l’offre' : 'Nouvelle offre'} subtitle="Les champs marqués d’un astérisque sont obligatoires." onClose={onClose} wide>
    <Form {...form}><form onSubmit={form.handleSubmit(submit)} className="space-y-5">
      <div className="grid gap-3 sm:grid-cols-2"><Field name="client" label="Client" form={form} required placeholder="Organisation / entreprise"/><Field name="ref" label="Référence" form={form} required placeholder="ex. MF-2025-014"/><Field name="contact" label="Contact" form={form} placeholder="Nom du contact"/><Field name="email" label="E-mail" form={form} type="email" placeholder="contact@entreprise.tn"/><Field name="formation" label="Formation" form={form} required placeholder="Intitulé de la formation"/><Field name="hackerspace" label="Lieu / hackerspace" form={form} placeholder="Site de formation"/></div>
      <div className="border-t border-border pt-4"><p className="mb-3 text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Organisation</p><div className="grid gap-3 sm:grid-cols-3">
        <Field name="participantCount" label="Participants" form={form} type="number"/><Field name="hoursPerDay" label="Heures / jour" form={form} type="number"/><Field name="days" label="Nombre de jours" form={form} type="number"/><Field name="pauseMinutesPerDay" label="Pause (min / jour)" form={form} type="number"/><Field name="trainerRatePerHour" label="Tarif formateur / h" form={form} type="number"/><Field name="transportFees" label="Frais de transport" form={form} type="number"/>
      </div></div>
      <div className="border-t border-border pt-4"><p className="mb-3 text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Suivi commercial & financier</p><div className="grid gap-3 sm:grid-cols-3">
        <SelectField name="priority" label="Priorité" form={form} options={priorities}/><SelectField name="offerStatus" label="Étape de l’offre" form={form} options={stages}/><SelectField name="paymentStatus" label="Statut de paiement" form={form} options={payments}/>
        <Field name="amountExclTax" label="Montant HT (TND)" form={form} type="number"/><Field name="amountCollected" label="Montant encaissé (TND)" form={form} type="number"/>
        <FormField control={form.control} name="instructor" render={({ field }) => <FormItem className="space-y-1.5"><FormLabel className="text-[11px] font-semibold">Formateur</FormLabel><FormControl><select {...field} value={field.value ?? ''} className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm" data-testid="select-instructor"><option value="">À attribuer</option>{(instructorsQuery.data ?? []).map((item: Instructor) => <option key={item.id} value={item.name}>{item.name}</option>)}</select></FormControl></FormItem>}/>
        <Field name="submittedAt" label="Date d’envoi" form={form} type="date"/><Field name="startDate" label="Date de début" form={form} type="date"/><div className="sm:col-span-3"><Field name="details" label="Notes / détails" form={form} multiline placeholder="Contexte, besoins ou remarques"/></div>
      </div></div>
      {(create.isError || update.isError) && <p className="text-sm text-destructive" data-testid="text-form-error">L’enregistrement a échoué. Vérifiez les informations puis réessayez.</p>}
      <div className="flex justify-end gap-2 border-t border-border pt-4"><Button type="button" variant="outline" onClick={onClose} data-testid="button-cancel-offer">Annuler</Button><Button type="submit" disabled={busy} data-testid="button-save-offer">{busy && <LoaderCircle className="mr-2 animate-spin" size={15}/>} {offer ? 'Enregistrer les modifications' : 'Créer l’offre'}</Button></div>
    </form></Form>
  </Modal>;
}

function Dashboard() {
  const offersQuery = useGetOffers(); const summaryQuery = useGetOfferSummary();
  const archive = useArchiveOffer(); const qc = useQueryClient();
  const [search, setSearch] = useState(''); const [stage, setStage] = useState('Toutes les étapes'); const [priority, setPriority] = useState('Toutes les priorités'); const [payment, setPayment] = useState('Tous les paiements');
  const [editing, setEditing] = useState<Offer | undefined>(); const [creating, setCreating] = useState(false);
  const [importFeedback, setImportFeedback] = useState<ImportFeedback | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const createImport = useCreateOffer();
  const offers = offersQuery.data ?? [];
  const filtered = useMemo(() => offers.filter(o => {
    const match = `${o.client} ${o.ref} ${o.formation} ${o.instructor ?? ''}`.toLowerCase().includes(search.toLowerCase());
    return match && (stage === 'Toutes les étapes' || o.offerStatus === stage) && (priority === 'Toutes les priorités' || o.priority === priority) && (payment === 'Tous les paiements' || o.paymentStatus === payment);
  }), [offers, search, stage, priority, payment]);
  const fileRef = useRef<HTMLInputElement>(null);
  const importWorkbook = async (file?: File) => {
    if (!file) return;
    setImportFeedback(null);
    setIsImporting(true);
    let created = 0;
    const issues: string[] = [];
    try {
      const rows = await readWorkbookRows(file);
      if (!rows.length) throw new Error('Aucune ligne de données trouvée dans la première feuille.');
      for (const { rowNumber, values } of rows) {
        const rawPriority = cellText(workbookValue(values, 'Priorité', 'priority'));
        const rawStage = cellText(workbookValue(values, 'Étape de l’offre', 'Étape', 'offerStatus', 'Offer status'));
        const rawPayment = cellText(workbookValue(values, 'Statut de paiement', 'paymentStatus', 'Payment status'));
        const parsed = offerSchema.safeParse({
          client: cellText(workbookValue(values, 'Client', 'client')),
          ref: cellText(workbookValue(values, 'Référence', 'Réf.', 'ref', 'reference')),
          contact: cellText(workbookValue(values, 'Contact', 'contact')),
          email: cellText(workbookValue(values, 'E-mail', 'Email', 'email')),
          details: cellText(workbookValue(values, 'Détails', 'Notes', 'details')),
          formation: cellText(workbookValue(values, 'Formation', 'Intitulé de la formation', 'formation')),
          hackerspace: cellText(workbookValue(values, 'Lieu / hackerspace', 'Lieu', 'hackerspace')),
          participantCount: cellNumber(workbookValue(values, 'Participants', 'Nombre de participants', 'participantCount'), 1),
          pauseMinutesPerDay: cellNumber(workbookValue(values, 'Pause (min / jour)', 'Pause minutes par jour', 'pauseMinutesPerDay'), 0),
          trainerRatePerHour: cellNumber(workbookValue(values, 'Tarif formateur / heure', 'Tarif formateur / h', 'trainerRatePerHour'), 0),
          transportFees: cellNumber(workbookValue(values, 'Frais de transport', 'transportFees'), 0),
          hoursPerDay: cellNumber(workbookValue(values, 'Heures / jour', 'Heures par jour', 'hoursPerDay'), 0),
          days: cellNumber(workbookValue(values, 'Nombre de jours', 'Jours', 'days'), 0),
          instructor: cellText(workbookValue(values, 'Formateur', 'instructor')),
          priority: rawPriority || 'Moyenne',
          offerStatus: rawStage || 'Prospect',
          paymentStatus: rawPayment || 'Non Payé',
          amountExclTax: cellNumber(workbookValue(values, 'Montant HT (TND)', 'Montant HT', 'amountExclTax'), 0),
          amountCollected: cellNumber(workbookValue(values, 'Montant encaissé (TND)', 'Montant encaissé', 'amountCollected'), 0),
          submittedAt: workbookDate(workbookValue(values, 'Date d’envoi', 'Date envoi', 'submittedAt')),
          startDate: workbookDate(workbookValue(values, 'Date de début', 'Début prévu', 'startDate')),
        });
        if (!parsed.success) {
          const reason = parsed.error.issues.map(issue => `${issue.path.join('.') || 'ligne'} : ${issue.message}`).join('; ');
          issues.push(`Ligne ${rowNumber} : ${reason}`);
          continue;
        }
        const valuesToSend = parsed.data;
        const payload: OfferInput = {
          ...valuesToSend,
          contact: valuesToSend.contact || null, email: valuesToSend.email || null,
          details: valuesToSend.details || null, hackerspace: valuesToSend.hackerspace || null,
          instructor: valuesToSend.instructor || null, submittedAt: valuesToSend.submittedAt || null,
          startDate: valuesToSend.startDate || null,
        };
        try {
          await createImport.mutateAsync({ data: payload });
          created += 1;
        } catch (error) {
          issues.push(`Ligne ${rowNumber} : ${importErrorMessage(error)}`);
        }
      }
      if (created) {
        await qc.invalidateQueries({ queryKey: getGetOffersQueryKey() });
        await qc.invalidateQueries({ queryKey: getGetOfferSummaryQueryKey() });
      }
      setImportFeedback(issues.length
        ? { kind: 'error', message: `${created} offre${created === 1 ? '' : 's'} importée${created === 1 ? '' : 's'} ; ${issues.length} ligne${issues.length === 1 ? '' : 's'} à corriger.`, issues: issues.slice(0, 5) }
        : { kind: 'success', message: `${created} offre${created === 1 ? '' : 's'} importée${created === 1 ? '' : 's'} avec succès.` });
    } catch (error) {
      setImportFeedback({ kind: 'error', message: `Import impossible : ${importErrorMessage(error)}` });
    } finally {
      setIsImporting(false);
    }
  };
  const exportWorkbook = async () => {
    try {
      await exportOffersWorkbook(filtered);
      setImportFeedback({ kind: 'success', message: `Classeur Excel téléchargé : ${filtered.length} offre${filtered.length === 1 ? '' : 's'}.` });
    } catch (error) {
      setImportFeedback({ kind: 'error', message: `Export impossible : ${importErrorMessage(error)}` });
    }
  };
  const summary = summaryQuery.data;
  return <div className="fade-up">
    <PageTitle eyebrow="Pilotage commercial" title="Pipeline des offres" detail="Une vue claire sur les ventes, les encaissements et le travail à venir." action={<Button onClick={() => setCreating(true)} className="h-10 gap-2 bg-[hsl(var(--primary))] px-4" data-testid="button-new-offer"><Plus size={16}/>Nouvelle offre</Button>}/>
    <section className="mb-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-7" aria-label="Résumé financier">
      {summaryQuery.isLoading ? [0,1,2,3,4,5,6].map(i => <div key={i} className="h-[112px] animate-pulse rounded-xl bg-muted" data-testid={`skeleton-metric-${i}`}/>) : summaryQuery.isError ? <div className="sm:col-span-2 xl:col-span-7 rounded-xl border border-border bg-card"><StatePanel type="error" onRetry={() => summaryQuery.refetch()}/></div> : <>
        <Metric label="Offres actives" value={String(summary?.totalOffers ?? 0)} note={`${summary?.closedOffers ?? 0} clôturées`} icon={FileText}/>
        <Metric label="Montant proposé" value={money(summary?.totalQuoted ?? 0)} note="Total des offres HT" icon={TrendingUp} tone="blue"/>
        <Metric label="Déjà encaissé" value={money(summary?.totalCollected ?? 0)} note="Paiements reçus" icon={Banknote}/>
        <Metric label="À encaisser" value={money(summary?.totalOutstanding ?? 0)} note="Solde restant" icon={Clock3} tone="orange"/>
        <Metric label="Charges estimées" value={money(summary?.totalCharges ?? 0)} note="Honoraires + transport" icon={Calculator} tone="orange"/>
        <Metric label="Gain estimé HT" value={money(summary?.totalGain ?? 0)} note="Montant HT − charges" icon={Activity}/>
        <div className="relative flex flex-col justify-between overflow-hidden rounded-xl bg-[hsl(var(--primary))] p-5 text-white">
          <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-[.1em] text-white/70">Clôture commerciale <BadgeCheck size={17} className="text-white/70"/></div>
          <div className="mt-3 font-display text-[28px] font-extrabold tracking-[-.04em]" data-testid="metric-closed-ratio">{summary?.totalOffers ? Math.round((summary.closedOffers / summary.totalOffers) * 100) : 0}<span className="ml-1 text-base font-semibold text-white/65">%</span></div>
          <div className="mt-1 text-[11px] text-white/65">Taux de réussite des offres</div>
        </div>
      </>}
    </section>
    <section className="overflow-hidden rounded-xl border border-border bg-card shadow-[0_2px_12px_rgba(32,48,54,.025)]">
      <div className="flex flex-col justify-between gap-4 border-b border-border px-4 py-4 md:flex-row md:items-center md:px-5">
        <div><div className="flex items-center gap-2"><h2 className="m-0 font-display text-lg font-extrabold tracking-tight">Suivi des offres</h2><span className="rounded-full bg-muted px-2 py-0.5 font-mono text-[10px] text-muted-foreground" data-testid="text-offer-count">{filtered.length}</span></div><p className="mb-0 mt-1 text-xs text-muted-foreground">Recherchez, filtrez et ouvrez une offre pour la modifier.</p></div>
        <div className="flex flex-wrap gap-2"><input ref={fileRef} type="file" accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" className="hidden" data-testid="input-import-offers" onChange={e => { void importWorkbook(e.target.files?.[0]); e.currentTarget.value = ''; }}/>
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => fileRef.current?.click()} disabled={isImporting} data-testid="button-import-offers">{isImporting ? <LoaderCircle className="animate-spin" size={14}/> : <ArrowDownToLine size={14}/>}Importer Excel</Button>
          <Button variant="outline" size="sm" className="gap-1.5" onClick={exportWorkbook} disabled={!filtered.length} data-testid="button-export-offers"><FileSpreadsheet size={14}/>Exporter Excel</Button>
        </div>
      </div>
      <div className="px-4 md:px-5"><ImportNotice feedback={importFeedback}/></div>
      <div className="flex flex-col gap-2 border-b border-border bg-muted/35 p-3 md:flex-row md:px-5">
        <label className="relative min-w-[200px] flex-1"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={15}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Client, référence, formation…" className="h-9 w-full rounded-md border border-input bg-card pl-9 pr-3 text-xs outline-none focus:ring-2 focus:ring-ring" data-testid="input-search-offers"/></label>
        <div className="flex flex-wrap gap-2">
          {[['stage',stage,setStage,['Toutes les étapes',...stages]],['priority',priority,setPriority,['Toutes les priorités',...priorities]],['payment',payment,setPayment,['Tous les paiements',...payments]]].map(([key,val,setter,opts]: any) => <div key={key} className="relative"><select value={val} onChange={e => setter(e.target.value)} className="h-9 max-w-[190px] appearance-none rounded-md border border-input bg-card py-0 pl-3 pr-8 text-[11px] font-medium outline-none focus:ring-2 focus:ring-ring" data-testid={`filter-${key}`}>{opts.map((opt: string) => <option key={opt}>{opt}</option>)}</select><ChevronDown size={13} className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground"/></div>)}
        </div>
      </div>
      {offersQuery.isLoading ? <StatePanel type="loading"/> : offersQuery.isError ? <StatePanel type="error" onRetry={() => offersQuery.refetch()}/> :
      filtered.length === 0 ? <StatePanel type="empty"/> :
      <div className="scrollbar-thin overflow-x-auto">
        <table className="w-full min-w-[980px] border-collapse text-left">
          <thead><tr className="bg-muted/45 text-[9px] font-bold uppercase tracking-[.12em] text-muted-foreground"><th className="px-5 py-3">Client / Réf.</th><th className="px-4 py-3">Formation</th><th className="px-4 py-3">Étape</th><th className="px-4 py-3">Priorité</th><th className="px-4 py-3">Paiement</th><th className="px-4 py-3 text-right">Montant HT</th><th className="px-4 py-3">Début prévu</th><th className="px-4 py-3 text-right">Actions</th></tr></thead>
          <tbody>{filtered.map(offer => <tr key={offer.id} className="group border-t border-border/70 transition-colors hover:bg-muted/35" data-testid={`row-offer-${offer.id}`}>
            <td className="px-5 py-3.5"><div className="font-semibold text-[13px]" data-testid={`text-client-${offer.id}`}>{offer.client}</div><div className="mt-1 font-mono text-[10px] text-muted-foreground">{offer.ref}</div></td>
            <td className="px-4 py-3.5"><div className="max-w-[190px] truncate text-xs font-medium">{offer.formation}</div><div className="mt-1 text-[10px] text-muted-foreground">{offer.participantCount} participant{offer.participantCount > 1 ? 's' : ''}</div></td>
            <td className="px-4 py-3.5"><StatusPill label={offer.offerStatus}/></td><td className="px-4 py-3.5"><StatusPill label={offer.priority}/></td><td className="px-4 py-3.5"><StatusPill label={offer.paymentStatus}/></td>
            <td className="px-4 py-3.5 text-right font-mono text-xs font-medium">{money(offer.amountExclTax)}</td><td className="px-4 py-3.5 text-xs text-muted-foreground">{dateText(offer.startDate)}</td>
            <td className="px-4 py-3.5 text-right"><div className="inline-flex gap-1 opacity-100 transition-opacity md:opacity-0 md:group-hover:opacity-100"><button onClick={() => setEditing(offer)} title="Modifier" className="grid h-8 w-8 place-items-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground" data-testid={`button-edit-offer-${offer.id}`}><Pencil size={14}/></button><button onClick={() => { if (window.confirm(`Archiver l’offre ${offer.ref} ?`)) archive.mutate({ id: offer.id }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetOffersQueryKey() }); qc.invalidateQueries({ queryKey: getGetOfferSummaryQueryKey() }); } }); }} title="Archiver" className="grid h-8 w-8 place-items-center rounded-md text-muted-foreground hover:bg-rose-50 hover:text-rose-700" data-testid={`button-archive-offer-${offer.id}`}><Trash2 size={14}/></button></div></td>
          </tr>)}</tbody>
        </table>
      </div>}
      <div className="flex flex-col justify-between gap-1 border-t border-border px-5 py-3 text-[10px] text-muted-foreground sm:flex-row"><span>Affichage de {filtered.length} sur {offers.length} offres</span><span>Montants exprimés en dinars tunisiens (TND)</span></div>
    </section>
    {(creating || editing) && <OfferFormModal offer={editing} onClose={() => { setCreating(false); setEditing(undefined); }}/>}
    {archive.isError && <div className="fixed bottom-4 right-4 z-40 rounded-lg bg-destructive px-4 py-3 text-sm text-white" data-testid="text-archive-error">L’archivage a échoué. Réessayez.</div>}
  </div>;
}

function InstructorModal({ instructor, onClose }: { instructor?: Instructor; onClose: () => void }) {
  const qc = useQueryClient(); const create = useCreateInstructor(); const update = useUpdateInstructor();
  const form = useForm<InstructorValues>({ resolver: zodResolver(instructorSchema), defaultValues: { name: instructor?.name ?? '', email: instructor?.email ?? '', phone: instructor?.phone ?? '', track: instructor?.track ?? '' } });
  const done = () => { qc.invalidateQueries({ queryKey: getGetInstructorsQueryKey() }); onClose(); };
  return <Modal title={instructor ? 'Modifier le profil' : 'Ajouter un formateur'} subtitle="Coordonnées et spécialité de formation." onClose={onClose}>
    <Form {...form}><form className="space-y-4" onSubmit={form.handleSubmit(v => {
      const data: InstructorInput = { name: v.name, email: v.email || null, phone: v.phone || null, track: v.track || null };
      if (instructor) update.mutate({ id: instructor.id, data }, { onSuccess: done }); else create.mutate({ data }, { onSuccess: done });
    })}>
      <Field name="name" label="Nom complet" form={form} required placeholder="Prénom et nom"/><Field name="email" label="E-mail" form={form} type="email" placeholder="nom@exemple.tn"/><Field name="phone" label="Téléphone" form={form} placeholder="+216 …"/><Field name="track" label="Spécialité / parcours" form={form} placeholder="Développement web, réseau…"/>
      {(create.isError || update.isError) && <p className="text-sm text-destructive">Impossible d’enregistrer ce profil.</p>}
      <div className="flex justify-end gap-2 border-t border-border pt-4"><Button type="button" variant="outline" onClick={onClose} data-testid="button-cancel-instructor">Annuler</Button><Button type="submit" disabled={create.isPending || update.isPending} data-testid="button-save-instructor">{create.isPending || update.isPending ? 'Enregistrement…' : 'Enregistrer le profil'}</Button></div>
    </form></Form>
  </Modal>;
}
function Instructors() {
  const query = useGetInstructors(); const qc = useQueryClient(); const remove = useDeleteInstructor();
  const [editing, setEditing] = useState<Instructor | undefined>(); const [creating, setCreating] = useState(false); const [search, setSearch] = useState('');
  const fileRef = useRef<HTMLInputElement>(null); const create = useCreateInstructor();
  const [importFeedback, setImportFeedback] = useState<ImportFeedback | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const list = (query.data ?? []).filter(i => `${i.name} ${i.email ?? ''} ${i.track ?? ''}`.toLowerCase().includes(search.toLowerCase()));
  const importWorkbook = async (file?: File) => {
    if (!file) return;
    setImportFeedback(null);
    setIsImporting(true);
    let created = 0;
    const issues: string[] = [];
    try {
      const rows = await readWorkbookRows(file);
      if (!rows.length) throw new Error('Aucune ligne de données trouvée dans la première feuille.');
      for (const { rowNumber, values } of rows) {
        const parsed = instructorSchema.safeParse({
          name: cellText(workbookValue(values, 'Nom complet', 'Formateur', 'Nom', 'name')),
          email: cellText(workbookValue(values, 'E-mail', 'Email', 'email')),
          phone: cellText(workbookValue(values, 'Téléphone', 'Tél', 'phone')),
          track: cellText(workbookValue(values, 'Spécialité / parcours', 'Spécialité', 'Parcours', 'track')),
        });
        if (!parsed.success) {
          issues.push(`Ligne ${rowNumber} : ${parsed.error.issues.map(issue => issue.message).join('; ')}`);
          continue;
        }
        const data: InstructorInput = {
          name: parsed.data.name, email: parsed.data.email || null,
          phone: parsed.data.phone || null, track: parsed.data.track || null,
        };
        try {
          await create.mutateAsync({ data });
          created += 1;
        } catch (error) {
          issues.push(`Ligne ${rowNumber} : ${importErrorMessage(error)}`);
        }
      }
      if (created) await qc.invalidateQueries({ queryKey: getGetInstructorsQueryKey() });
      setImportFeedback(issues.length
        ? { kind: 'error', message: `${created} profil${created === 1 ? '' : 's'} importé${created === 1 ? '' : 's'} ; ${issues.length} ligne${issues.length === 1 ? '' : 's'} à corriger.`, issues: issues.slice(0, 5) }
        : { kind: 'success', message: `${created} profil${created === 1 ? '' : 's'} importé${created === 1 ? '' : 's'} avec succès.` });
    } catch (error) {
      setImportFeedback({ kind: 'error', message: `Import impossible : ${importErrorMessage(error)}` });
    } finally {
      setIsImporting(false);
    }
  };
  const exportWorkbook = async () => {
    try {
      await exportInstructorsWorkbook(query.data ?? []);
      setImportFeedback({ kind: 'success', message: `Classeur Excel téléchargé : ${query.data?.length ?? 0} formateur${query.data?.length === 1 ? '' : 's'}.` });
    } catch (error) {
      setImportFeedback({ kind: 'error', message: `Export impossible : ${importErrorMessage(error)}` });
    }
  };
  return <div className="fade-up">
    <PageTitle eyebrow="Ressources pédagogiques" title="Formateurs" detail="L’annuaire des intervenants et de leurs domaines d’expertise." action={<Button onClick={() => setCreating(true)} className="h-10 gap-2" data-testid="button-new-instructor"><Plus size={16}/>Ajouter un formateur</Button>}/>
    <section className="mb-6 grid gap-3 sm:grid-cols-3">
      <Metric label="Formateurs référencés" value={String(query.data?.length ?? 0)} note="Dans l’annuaire" icon={Users}/>
      <Metric label="Spécialités" value={String(new Set((query.data ?? []).map(x => x.track).filter(Boolean)).size)} note="Domaines couverts" icon={GraduationCap} tone="blue"/>
      <Metric label="Ajout récent" value={query.data?.length ? dateText([...query.data].sort((a,b) => b.createdAt.localeCompare(a.createdAt))[0]?.createdAt) : '—'} note="Dernier profil créé" icon={CalendarDays} tone="orange"/>
    </section>
    <section className="overflow-hidden rounded-xl border border-border bg-card">
      <div className="flex flex-col justify-between gap-3 border-b border-border p-4 sm:flex-row sm:items-center sm:px-5">
        <div><h2 className="m-0 font-display text-lg font-extrabold">Annuaire</h2><p className="mb-0 mt-1 text-xs text-muted-foreground">Coordonnées à jour, équipe prête à intervenir.</p></div>
        <div className="flex flex-wrap gap-2"><input ref={fileRef} type="file" accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" className="hidden" onChange={e => { void importWorkbook(e.target.files?.[0]); e.currentTarget.value = ''; }} data-testid="input-import-instructors"/><Button size="sm" variant="outline" onClick={() => fileRef.current?.click()} disabled={isImporting} className="gap-1.5" data-testid="button-import-instructors">{isImporting ? <LoaderCircle className="animate-spin" size={14}/> : <ArrowDownToLine size={14}/>}Importer Excel</Button>
          <Button size="sm" variant="outline" onClick={exportWorkbook} disabled={!query.data?.length} className="gap-1.5" data-testid="button-export-instructors"><FileSpreadsheet size={14}/>Exporter Excel</Button>
          <label className="relative min-w-[175px] flex-1 sm:flex-none"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={14}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher…" className="h-9 w-full rounded-md border border-input bg-background pl-9 pr-3 text-xs outline-none focus:ring-2 focus:ring-ring" data-testid="input-search-instructors"/></label></div>
      </div>
      <div className="px-4 md:px-5"><ImportNotice feedback={importFeedback}/></div>
      {query.isLoading ? <StatePanel type="loading"/> : query.isError ? <StatePanel type="error" onRetry={() => query.refetch()}/> : list.length === 0 ? <StatePanel type="empty"/> :
      <div className="scrollbar-thin overflow-x-auto"><table className="w-full min-w-[700px] border-collapse text-left">
        <thead><tr className="bg-muted/45 text-[9px] font-bold uppercase tracking-[.12em] text-muted-foreground"><th className="px-5 py-3">Formateur</th><th className="px-4 py-3">Spécialité</th><th className="px-4 py-3">Téléphone</th><th className="px-4 py-3">E-mail</th><th className="px-4 py-3">Depuis</th><th className="px-5 py-3 text-right">Actions</th></tr></thead>
        <tbody>{list.map((i, n) => <tr key={i.id} className="group border-t border-border/70 hover:bg-muted/35" data-testid={`row-instructor-${i.id}`}>
          <td className="px-5 py-4"><div className="flex items-center gap-3"><div className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl text-xs font-bold ${n % 3 === 0 ? 'bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]' : n % 3 === 1 ? 'bg-[hsl(var(--accent))]/10 text-[hsl(var(--accent))]' : 'bg-sky-900/10 text-sky-900'}`} data-testid={`avatar-instructor-${i.id}`}>{i.name.split(/\s+/).slice(0,2).map(s => s[0]).join('').toUpperCase()}</div><span className="text-sm font-semibold" data-testid={`text-instructor-${i.id}`}>{i.name}</span></div></td>
          <td className="px-4 py-4"><span className="rounded-md bg-muted px-2.5 py-1 text-[11px] font-medium">{i.track || 'À préciser'}</span></td><td className="px-4 py-4 text-xs text-muted-foreground">{i.phone || '—'}</td><td className="px-4 py-4 text-xs text-muted-foreground">{i.email || '—'}</td><td className="px-4 py-4 text-xs text-muted-foreground">{dateText(i.createdAt)}</td>
          <td className="px-5 py-4 text-right"><div className="inline-flex gap-1 opacity-100 md:opacity-0 md:group-hover:opacity-100"><button onClick={() => setEditing(i)} title="Modifier" className="grid h-8 w-8 place-items-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground" data-testid={`button-edit-instructor-${i.id}`}><Pencil size={14}/></button><button onClick={() => { if (window.confirm(`Supprimer le profil de ${i.name} ?`)) remove.mutate({ id: i.id }, { onSuccess: () => qc.invalidateQueries({ queryKey: getGetInstructorsQueryKey() }) }); }} title="Supprimer" className="grid h-8 w-8 place-items-center rounded-md text-muted-foreground hover:bg-rose-50 hover:text-rose-700" data-testid={`button-delete-instructor-${i.id}`}><Trash2 size={14}/></button></div></td>
        </tr>)}</tbody>
      </table></div>}
      <div className="border-t border-border px-5 py-3 text-[10px] text-muted-foreground">Classeur Excel attendu : Nom complet, E-mail, Téléphone, Spécialité / parcours.</div>
    </section>
    {remove.isError && <div className="mt-3 text-sm text-destructive" data-testid="text-delete-error">La suppression du formateur a échoué.</div>}
    {(creating || editing) && <InstructorModal instructor={editing} onClose={() => { setCreating(false); setEditing(undefined); }}/>}
  </div>;
}

function Simulation() {
  const [participants, setParticipants] = useState(12); const [hours, setHours] = useState(6); const [days, setDays] = useState(2); const [pause, setPause] = useState(60);
  const [rate, setRate] = useState(85); const [transport, setTransport] = useState(120); const [margin, setMargin] = useState(25);
  const paidHours = Math.max(0, hours - pause / 60) * days;
  const trainerCost = paidHours * rate; const directCost = trainerCost + transport; const quote = margin < 100 ? directCost / (1 - margin / 100) : 0; const perPerson = participants ? quote / participants : 0;
  const numericField = (label: string, value: number, setter: (n: number) => void, id: string, suffix?: string) => <label className="block"><span className="mb-1.5 block text-[11px] font-semibold">{label}</span><div className="relative"><Input type="number" min="0" value={value} onChange={e => setter(Number(e.target.value))} className="h-11 bg-background pr-12 font-mono" data-testid={`input-sim-${id}`}/>{suffix && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground">{suffix}</span>}</div></label>;
  return <div className="fade-up">
    <PageTitle eyebrow="Préparation d’offre" title="Simulateur de coûts" detail="Estimez votre prix de vente à partir des frais opérationnels."/>
    <div className="grid gap-5 lg:grid-cols-[1.08fr_.92fr]">
      <section className="rounded-xl border border-border bg-card p-5 md:p-7">
        <div className="mb-6 flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]"><Calculator size={19}/></div><div><h2 className="m-0 font-display text-lg font-extrabold">Paramètres de formation</h2><p className="mb-0 mt-1 text-xs text-muted-foreground">Ajustez les valeurs pour obtenir une estimation.</p></div></div>
        <div className="space-y-6"><div><div className="mb-3 text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Format & durée</div><div className="grid gap-4 sm:grid-cols-2">{numericField('Nombre de participants', participants, setParticipants, 'participants', 'pers.')}{numericField('Heures de formation / jour', hours, setHours, 'hours', 'h')}{numericField('Nombre de jours', days, setDays, 'days', 'j')}{numericField('Pause non facturée / jour', pause, setPause, 'pause', 'min')}</div></div>
          <div className="border-t border-border pt-5"><div className="mb-3 text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Coûts directs</div><div className="grid gap-4 sm:grid-cols-2">{numericField('Tarif formateur / heure', rate, setRate, 'rate', 'TND')}{numericField('Transport & logistique', transport, setTransport, 'transport', 'TND')}</div></div>
          <div className="border-t border-border pt-5"><div className="mb-3 text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Politique commerciale</div><div className="max-w-[calc(50%-8px)]">{numericField('Marge cible', margin, setMargin, 'margin', '%')}</div><input type="range" min="0" max="70" value={margin} onChange={e => setMargin(Number(e.target.value))} className="mt-4 w-full accent-[hsl(var(--primary))]" aria-label="Marge cible" data-testid="slider-sim-margin"/><div className="flex justify-between text-[10px] text-muted-foreground"><span>Sans marge</span><span>70 %</span></div></div>
        </div>
      </section>
      <aside className="flex flex-col gap-4">
        <section className="relative overflow-hidden rounded-xl bg-[hsl(var(--sidebar))] p-6 text-white md:p-8">
          <div className="absolute -right-8 -top-8 h-44 w-44 rounded-full border border-white/10"/><div className="absolute -right-2 top-0 h-32 w-32 rounded-full border border-white/10"/>
          <div className="relative"><div className="mb-8 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-white/55"><TrendingUp size={14}/>Résultat estimatif</div><div className="text-xs text-white/60">Prix de vente conseillé HT</div><div className="mt-2 font-display text-[44px] font-extrabold leading-none tracking-[-.055em]" data-testid="text-sim-quote">{money(quote)}</div><div className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-[11px] font-semibold text-white/80"><Users size={13}/>{money(perPerson)} par participant</div>
            <div className="mt-8 grid grid-cols-2 gap-3"><div className="rounded-lg border border-white/10 bg-white/[.05] p-3"><div className="text-[10px] uppercase tracking-wider text-white/45">Heures facturables</div><div className="mt-1 font-mono text-lg font-medium">{paidHours.toLocaleString('fr-TN')} h</div></div><div className="rounded-lg border border-white/10 bg-white/[.05] p-3"><div className="text-[10px] uppercase tracking-wider text-white/45">Marge calculée</div><div className="mt-1 font-mono text-lg font-medium">{money(quote - directCost)}</div></div></div>
          </div>
        </section>
        <section className="rounded-xl border border-border bg-card p-5"><h3 className="mb-4 mt-0 font-display text-sm font-extrabold">Détail du calcul</h3>
          <div className="space-y-3 text-xs"><div className="flex justify-between"><span className="text-muted-foreground">Honoraires formateur</span><span className="font-mono">{money(trainerCost)}</span></div><div className="flex justify-between"><span className="text-muted-foreground">Transport & logistique</span><span className="font-mono">{money(transport)}</span></div><div className="flex justify-between border-t border-border pt-3"><span className="font-semibold">Coût opérationnel</span><span className="font-mono font-semibold">{money(directCost)}</span></div><div className="flex justify-between text-[hsl(var(--primary))]"><span>Marge cible ({margin} % du prix)</span><span className="font-mono">+{money(quote - directCost)}</span></div><div className="flex justify-between border-t border-border pt-3 text-sm font-bold"><span>Montant HT conseillé</span><span className="font-mono">{money(quote)}</span></div></div>
        </section>
        <p className="m-0 flex items-start gap-2 px-1 text-[10px] leading-relaxed text-muted-foreground"><CircleAlert size={13} className="mt-0.5 shrink-0"/>Estimation indicative. Les frais fixes sont répartis sur le groupe ; confirmez toujours le devis final.</p>
      </aside>
    </div>
  </div>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function Router() {
  return <Shell><RoutedErrorBoundary><Switch><Route path="/" component={Dashboard}/><Route path="/instructors" component={Instructors}/><Route path="/simulation" component={Simulation}/><Route component={NotFound}/></Switch></RoutedErrorBoundary></Shell>;
}
function App() {
  return <QueryClientProvider client={client}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router/></WouterRouter><Toaster/></TooltipProvider></QueryClientProvider>;
}
export default App;