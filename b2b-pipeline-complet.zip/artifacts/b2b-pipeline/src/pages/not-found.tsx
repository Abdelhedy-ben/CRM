import { Link } from 'wouter';
import { ArrowLeft, Compass } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function NotFound() {
  return <div className="grid min-h-[58vh] place-items-center py-12 text-center" data-testid="state-not-found">
    <div className="max-w-md">
      <div className="mx-auto mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]"><Compass size={26}/></div>
      <p className="mb-2 font-mono text-xs font-medium tracking-[.2em] text-[hsl(var(--accent))]">ERREUR 404</p>
      <h1 className="m-0 font-display text-3xl font-extrabold tracking-tight">Cette page n’existe pas.</h1>
      <p className="mx-auto mb-6 mt-3 max-w-sm text-sm leading-relaxed text-muted-foreground">Le lien a peut-être changé. Retrouvez le pipeline et poursuivez votre suivi depuis l’accueil.</p>
      <Button asChild data-testid="button-back-home"><Link href="/" className="inline-flex items-center gap-2"><ArrowLeft size={15}/>Retour au pipeline</Link></Button>
    </div>
  </div>;
}